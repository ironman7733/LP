package com.ems.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EmployeeController
 */
@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1> Employee Servlet </h1>");
		String id = request.getParameter("empid");
		String name = request.getParameter("empname");
		String [] hob = request.getParameterValues("c1");
		String gender = request.getParameter("r1");
		String city = request.getParameter("city");
		
		
		int empid = Integer.parseInt(id);
		out.println("<h1> FOLLOWING INFO SUBMITTED");
		out.println("<h1> EMP ID = "+empid);
		out.println("<h1> EMPLOYEE NAME ="+name);
		out.println("<h1> HOBBIES: <h1>");
		for(int i=0;i<hob.length;i++)
		{
			out.println("<h2> "+hob[i]);
		}
		out.println("<h1> GENDER ="+gender);
		out.println("<h1> city ="+city);
		out.println("<table border= \"1\"");
        out.println("<tr>"); out.println("<td> Empid</td>");
        out.println("<td> Empname</td></tr>");
        out.println("<tr>  "); out.println("<td>"+ empid+"</td>");
        out.println("<td>"+name+"</td></tr>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
