package com.employeepro.exception;

public class EmployeeProException  extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5622676167618486815L;
     public EmployeeProException(String message){
    	 
    	 super(message);
     }
	
}
