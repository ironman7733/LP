package com.employeepro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.employeepro.dto.EmployeeProDto;
import com.employeepro.exception.EmployeeProException;
import com.employeepro.util.DbConnection;

public class EmployeeProDaoImpl implements IEmployeeProDao {

	PreparedStatement preparedStatement = null;
	Connection con = null;
	ResultSet resultSet = null;
    
	@Override
	public int addEmployee(EmployeeProDto Employee) throws EmployeeProException {
        int result=0;
		try {
			con = DbConnection.getConnection();
			String qry= QueryMapper.INSERTQUERY;
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setString(1, Employee.getEmpname());
			pstmt.setDouble(2, Employee.getSalary());
			int count=pstmt.executeUpdate();
			if(count<=0)
			{
				throw new EmployeeProException("INSERT FAIL ");
			}
			qry=QueryMapper.GETSEQUENCEID;
			pstmt=con.prepareStatement(qry);
			ResultSet rst=pstmt.executeQuery();
			while(rst.next())
			{
				result=rst.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

}
