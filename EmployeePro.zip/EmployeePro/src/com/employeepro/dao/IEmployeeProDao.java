package com.employeepro.dao;

import com.employeepro.dto.EmployeeProDto;
import com.employeepro.exception.EmployeeProException;

public interface IEmployeeProDao {

	public int addEmployee(EmployeeProDto Employee) throws EmployeeProException;
}
