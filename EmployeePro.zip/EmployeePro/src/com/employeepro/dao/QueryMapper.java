package com.employeepro.dao;

public class QueryMapper {

	public static final String GETSEQUENCEID = "select emp_seq.currval from emp_tbl";
	public static final String INSERTQUERY = "insert into emp_tbl(empid,empname,empsalary) values(emp_seq.nextval,?,?)";
}
