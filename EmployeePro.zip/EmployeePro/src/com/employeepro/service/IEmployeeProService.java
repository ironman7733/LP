package com.employeepro.service;

import com.employeepro.dto.EmployeeProDto;
import com.employeepro.exception.EmployeeProException;

public interface IEmployeeProService {

	public int addEmployee(EmployeeProDto Employee) throws EmployeeProException;

}
