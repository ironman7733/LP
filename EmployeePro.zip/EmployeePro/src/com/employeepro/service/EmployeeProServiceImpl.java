package com.employeepro.service;

import com.employeepro.dao.EmployeeProDaoImpl;
import com.employeepro.dao.IEmployeeProDao;
import com.employeepro.dto.EmployeeProDto;
import com.employeepro.exception.EmployeeProException;

public class EmployeeProServiceImpl implements IEmployeeProService {
   IEmployeeProDao dao = new EmployeeProDaoImpl();
	@Override
	public int addEmployee(EmployeeProDto Employee) throws EmployeeProException {

		int result=0;
		result = dao.addEmployee(Employee);
		return result;
	}

}
