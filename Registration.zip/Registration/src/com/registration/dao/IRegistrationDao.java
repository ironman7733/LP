package com.registration.dao;

import com.registration.dto.RegistrationDto;
import com.registration.exception.RegistrationException;

public interface IRegistrationDao {
	public int addUser(RegistrationDto User) throws RegistrationException;

}
