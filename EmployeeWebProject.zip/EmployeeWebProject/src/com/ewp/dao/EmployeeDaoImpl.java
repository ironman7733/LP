package com.ewp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ewp.bean.EmployeeBean;
import com.ewp.exception.EmployeeException;
import com.ewp.util.DbConnection;


public class EmployeeDaoImpl implements IEmployeeDao{

	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		int id=0;
		Connection con=DbConnection.getConnection();
		try {
			PreparedStatement pstmt=con.prepareStatement("insert into emp_tab1 values(emp_seq1.nextval,?,?)");
			pstmt.setString(1,bean.getEmployeeName());
			pstmt.setDouble(2, bean.getEmployeeSalary());
			
			int count=pstmt.executeUpdate();
			if(count<=0)
			{
				throw new EmployeeException("Insertion Fail");
			}
			PreparedStatement pstmt2=con.prepareStatement("select emp_seq.currval from dual");
			ResultSet rst=pstmt2.executeQuery();
			if(rst.next())
			{
				id=rst.getInt(1);
				
			}
			else
			{
				throw new EmployeeException("Sequence not found or unable to get seq. number");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return id;
	}

}
