package com.ewp.service;

import com.ewp.bean.EmployeeBean;
import com.ewp.dao.EmployeeDaoImpl;
import com.ewp.dao.IEmployeeDao;
import com.ewp.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService{

	private IEmployeeDao dao=new EmployeeDaoImpl();
	
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		
		int id=0;
		id=dao.addEmployee(bean);
		return id;
		
	}

}
