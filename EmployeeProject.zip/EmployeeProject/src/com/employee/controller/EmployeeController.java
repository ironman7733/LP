package com.employee.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.employee.bean.EmployeeBean;
import com.employee.dao.EmployeeDaoImpl;
import com.employee.dao.IEmployeeDao;
import com.employee.exception.EmployeeException;
import com.employee.service.EmployeeServiceImpl;
import com.employee.service.IEmployeeService;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/EmployeeServlet")
public class EmployeeController extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeController() 
    {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
	    String employeeName = request.getParameter("empname");  
	    String salary = request.getParameter("empsalary");
	    double employeeSalary=Double.parseDouble(salary);
	    EmployeeBean bean = new EmployeeBean();
	    bean.setEmployeeName(employeeName);
	    bean.setEmployeeSalary(employeeSalary);
	    
	    IEmployeeService service = new EmployeeServiceImpl();
	    int empid = 0;
	    
	    try 
	    {
			empid = service.addEmployee(bean);
		} 
	    catch (EmployeeException e) 
	    {

			e.getMessage();
		}
	    
	    out.println("<h1>Employee Added Successfully</h1>");
		out.println("<h2>Employee ID = "+empid+"</h2>");
	    

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
	}

}
