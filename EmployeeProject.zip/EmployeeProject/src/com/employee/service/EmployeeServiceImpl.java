package com.employee.service;



import com.employee.bean.EmployeeBean;
import com.employee.dao.EmployeeDaoImpl;
import com.employee.dao.IEmployeeDao;
import com.employee.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService
{

	private IEmployeeDao dao=new EmployeeDaoImpl();
	
	@Override
		public int addEmployee(EmployeeBean bean) throws EmployeeException 
	{
		int id=0;
		id=dao.addEmployee(bean);
		
		return id;
	}	

}
