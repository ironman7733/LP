package com.employee.service;


import com.employee.bean.EmployeeBean;
import com.employee.exception.EmployeeException;

public interface IEmployeeService 
{

	public int addEmployee(EmployeeBean employee) throws EmployeeException;
}
