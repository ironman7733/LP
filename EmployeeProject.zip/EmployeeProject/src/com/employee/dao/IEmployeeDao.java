package com.employee.dao;

import com.employee.bean.EmployeeBean;
import com.employee.exception.EmployeeException;

public interface IEmployeeDao {
	
	public int addEmployee(EmployeeBean employee) throws EmployeeException;

}
